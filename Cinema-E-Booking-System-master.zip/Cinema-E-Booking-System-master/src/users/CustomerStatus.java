package users;

public enum CustomerStatus {
	ACTIVE, INACTIVE, SUSPENDED;
} // CustomerStatus